package com.tianbing.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

//创建自己的Controller注解,它只能标注在类上面
//注解的作用目标：接口、类、枚举、注解
@Target(ElementType.TYPE)
/**
 * 使用Retention修饰这个注解,
 * 告诉这个注解在使用的时候即可以
 * 用到.Class文件,
 * 又能在运行过程中通过反射的方式
 * 读取出来
 * @author Administrator
 *
 */
@Retention(RetentionPolicy.RUNTIME)
//说明该注解将被包含在javadoc中
@Documented
public @interface MyController {
	/**
	 * 表示给controller注册别名
	 * @return
	 */
	String value() default "";
	
}
